#pragma once

int SW_MAIN(int argc, char *argv[]);

#ifndef SW_MAIN_IMPL
#define main SW_MAIN
#endif
